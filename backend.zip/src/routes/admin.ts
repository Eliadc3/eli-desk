import { Router } from "express";
import bcrypt from "bcryptjs";
import { prisma } from "../lib/prisma.js";
import { HttpError } from "../lib/httpError.js";
import { Prisma, Permission, Role } from "@prisma/client";
import { requirePermission } from "../middleware/requirePermission.js";
import {
  technicianCreateSchema,
  technicianPatchSchema,
  departmentCreateSchema,
  departmentPatchSchema,
  ticketStatusCreateSchema,
  ticketStatusPatchSchema,
} from "./schemas.js";
import { userCtx } from "../lib/userCtx.js";

export const adminRouter = Router();

/* =========================
   Ticket Statuses (Admin)
   ========================= */

// List statuses for current org
adminRouter.get(
  "/ticket-statuses",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const { orgId } = userCtx(req);
      if (!orgId) throw new HttpError(400, "Missing orgId");

      const items = await prisma.ticketStatus.findMany({
        where: { orgId },
        orderBy: [{ sortOrder: "asc" }, { labelHe: "asc" }],
        select: {
          id: true,
          key: true,
          labelHe: true,
          color: true,
          sortOrder: true,
          isActive: true,
          isDefault: true,
        },
      });

      res.json({ items });
    } catch (e) {
      next(e);
    }
  }
);

// Create status
adminRouter.post(
  "/ticket-statuses",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const { orgId } = userCtx(req);
      if (!orgId) throw new HttpError(400, "Missing orgId");

      const body = ticketStatusCreateSchema.parse(req.body);

      // אם מסמנים default חדש – נבטל אחרים
      if (body.isDefault) {
        await prisma.ticketStatus.updateMany({
          where: { orgId, isDefault: true },
          data: { isDefault: false },
        });
      }

      const created = await prisma.ticketStatus.create({
        data: {
          orgId,
          key: body.key,
          labelHe: body.labelHe,
          color: body.color ?? null,
          sortOrder: body.sortOrder ?? 0,
          isActive: body.isActive ?? true,
          isDefault: body.isDefault ?? false,
        },
        select: {
          id: true,
          key: true,
          labelHe: true,
          color: true,
          sortOrder: true,
          isActive: true,
          isDefault: true,
        },
      });

      res.status(201).json(created);
    } catch (e) {
      next(e);
    }
  }
);

// Patch status (draft -> save)
adminRouter.patch(
  "/ticket-statuses/:id",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const { orgId } = userCtx(req);
      if (!orgId) throw new HttpError(400, "Missing orgId");

      const id = req.params.id;
      const body = ticketStatusPatchSchema.parse(req.body);

      // ודא שזה שייך לאותו org
      const existing = await prisma.ticketStatus.findFirst({
        where: { id, orgId },
        select: { id: true },
      });
      if (!existing) throw new HttpError(404, "Status not found");

      // אם הופך ל-default – מבטלים אחרים
      if (body.isDefault === true) {
        await prisma.ticketStatus.updateMany({
          where: { orgId, isDefault: true, NOT: { id } },
          data: { isDefault: false },
        });
      }

      const updated = await prisma.ticketStatus.update({
        where: { id },
        data: {
          key: body.key,
          labelHe: body.labelHe,
          color: body.color === undefined ? undefined : body.color,
          sortOrder: body.sortOrder,
          isActive: body.isActive,
          isDefault: body.isDefault,
        },
        select: {
          id: true,
          key: true,
          labelHe: true,
          color: true,
          sortOrder: true,
          isActive: true,
          isDefault: true,
        },
      });

      res.json(updated);
    } catch (e) {
      next(e);
    }
  }
);

// Delete status (עם הגנה אם יש קריאות שמשתמשות בו)
adminRouter.delete(
  "/ticket-statuses/:id",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const { orgId } = userCtx(req);
      if (!orgId) throw new HttpError(400, "Missing orgId");

      const id = req.params.id;

      const existing = await prisma.ticketStatus.findFirst({
        where: { id, orgId },
        select: { id: true, isDefault: true },
      });
      if (!existing) throw new HttpError(404, "Status not found");
      if (existing.isDefault) throw new HttpError(400, "Cannot delete default status");

      const used = await prisma.ticket.count({ where: { statusId: id } });
      if (used > 0) throw new HttpError(400, "Status is in use");

      await prisma.ticketStatus.delete({ where: { id } });
      res.json({ ok: true });
    } catch (e) {
      next(e);
    }
  }
);

/* =========================
   Departments
   ========================= */

adminRouter.get("/departments", requirePermission(Permission.DEPT_MANAGE), async (req, res, next) => {
  try {
    const active = String(req.query.active ?? "true").toLowerCase() !== "false"; // ✅ default: true

    const items = await prisma.department.findMany({
      where: { isActive: active },
      orderBy: [{ type: "asc" }, { name: "asc" }],
    });

    res.json({ items });
  } catch (e) { next(e); }
});



adminRouter.post(
  "/departments",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const body = departmentCreateSchema.parse(req.body);
      const created = await prisma.department.create({ data: body });
      res.status(201).json(created);
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.patch(
  "/departments/:id",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const id = req.params.id;
      const body = departmentPatchSchema.parse(req.body);
      const updated = await prisma.department.update({ where: { id }, data: body });
      res.json(updated);
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.get(
  "/departments/:id/usage",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const id = req.params.id;

      const dept = await prisma.department.findUnique({
        where: { id },
        select: { id: true, type: true },
      });
      if (!dept) throw new HttpError(404, "Department not found");

      const usedTickets =
        dept.type === "HOSPITAL"
          ? await prisma.ticket.count({ where: { hospitalDepartmentId: id } })
          : 0;

      const usedUsers =
        dept.type === "TECH"
          ? await prisma.user.count({ where: { techDepartmentId: id } })
          : 0;

      return res.json({ type: dept.type, usedTickets, usedUsers });
    } catch (e) {
      next(e);
    }
  }
);


/**
 * ✅ חדש: העברת קריאות של מחלקה למחלקה אחרת (רק לקריאות)
 * - שים לב: זה להעברת hospitalDepartmentId בלבד.
 */
adminRouter.post(
  "/departments/:id/reassign-tickets",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const fromId = req.params.id;
      const { toDepartmentId } = req.body ?? {};
      if (!toDepartmentId) throw new HttpError(400, "Missing toDepartmentId");
      if (fromId === toDepartmentId) throw new HttpError(400, "Cannot reassign to same department");

      const moved = await prisma.ticket.updateMany({
        where: { hospitalDepartmentId: fromId },
        data: { hospitalDepartmentId: toDepartmentId },
      });

      res.json({ ok: true, moved: moved.count });
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.delete(
  "/departments/:id",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const id = req.params.id;

      const existing = await prisma.department.findUnique({
        where: { id },
        select: { id: true, isActive: true },
      });
      if (!existing) throw new HttpError(404, "Department not found");

      // ✅ אחידות: תמיד Disable, בלי מחיקה קשיחה בכלל
      const updated = await prisma.department.update({
        where: { id },
        data: { isActive: false },
        select: { id: true, name: true, type: true, isActive: true },
      });

      return res.json({ ok: true, item: updated });
    } catch (e) {
      next(e);
    }
  }
);


adminRouter.delete(
  "/departments/:id/permanent",
  requirePermission(Permission.DEPT_MANAGE),
  async (req, res, next) => {
    try {
      const id = req.params.id;

      const dept = await prisma.department.findUnique({
        where: { id },
        select: { id: true, name: true, type: true, isActive: true },
      });
      if (!dept) throw new HttpError(404, "Department not found");

      // ✅ רק אם לא פעילה
      if (dept.isActive) throw new HttpError(400, "Cannot delete active department");

      // ✅ אם זו מחלקת בית חולים — בדוק קריאות משויכות + החזר מספרים
      if (dept.type === "HOSPITAL") {
        const tickets = await prisma.ticket.findMany({
          where: { hospitalDepartmentId: id },
          select: { number: true },
          orderBy: { number: "asc" },
        });

        if (tickets.length) {
          return res.status(409).json({
            error: "Department has tickets",
            details: { ticketNumbers: tickets.map((t) => t.number) },
          });
        }
      }

      // ✅ אם זו מחלקת טכנאים — אל תאפשר מחיקה אם יש טכנאים משויכים
      if (dept.type === "TECH") {
        const users = await prisma.user.findMany({
          where: { techDepartmentId: id },
          select: { id: true, username: true, name: true },
          orderBy: { name: "asc" },
        });

        if (users.length) {
          return res.status(409).json({
            error: "Department has technicians",
            details: {
              users: users.map((u) => ({ id: u.id, username: u.username, name: u.name })),
            },
          });
        }
      }

      await prisma.department.delete({ where: { id } });
      return res.json({ ok: true });
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.patch("/departments/:id/active", requirePermission(Permission.DEPT_MANAGE), async (req, res, next) => {
  try {
    const id = req.params.id;
    const { isActive } = req.body ?? {};
    if (typeof isActive !== "boolean") throw new HttpError(400, "Missing isActive boolean");

    const updated = await prisma.department.update({ where: { id }, data: { isActive } });
    res.json(updated);
  } catch (e) { next(e); }
});


/* =========================
   Assignees
   ========================= */

adminRouter.get(
  "/assignees",
  requirePermission(Permission.TICKET_REASSIGN),
  async (_req, res, next) => {
    try {
      const items = await prisma.user.findMany({
        where: { role: Role.TECHNICIAN, isActive: true },
        orderBy: { name: "asc" },
        select: { id: true, name: true },
      });

      res.json({ items });
    } catch (e) {
      next(e);
    }
  }
);

/* =========================
   Technicians
   ========================= */

adminRouter.get("/technicians", requirePermission(Permission.TECH_MANAGE), async (req, res, next) => {
  try {
    const active = String(req.query.active ?? "true").toLowerCase() !== "false"; // ✅ default: true

    const items = await prisma.user.findMany({
      where: { role: Role.TECHNICIAN, isActive: active },
      orderBy: { name: "asc" },
      include: { techDepartment: true, permissions: true },
    });

    res.json({ items });
  } catch (e) { next(e); }
});

adminRouter.post(
  "/technicians",
  requirePermission(Permission.TECH_MANAGE),
  async (req, res, next) => {
    try {
      const body = technicianCreateSchema.parse(req.body);
      const passwordHash = await bcrypt.hash(body.password, 10);

      let created: { id: string; username: string; name: string; role: Role; techDepartmentId: string | null; isActive: boolean };

      try {
        created = await prisma.user.create({
          data: {
            username: body.username,
            name: body.name,
            passwordHash,
            role: Role.TECHNICIAN,
            techDepartmentId: body.techDepartmentId,
          },
          select: { id: true, username: true, name: true, role: true, techDepartmentId: true, isActive: true },
        });
      } catch (e: any) {
        if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
          return res.status(409).json({
            error: "Username already exists",
            details: { field: "username" },
          });
        }
        throw e;
      }

      // Permissions
      if (body.permissions?.length) {
        const uniquePerms = Array.from(new Set(body.permissions));

        try {
          await prisma.userPermission.createMany({
            data: uniquePerms.map((p) => ({ userId: created.id, perm: p as any })),
          });
        } catch (e: any) {
          if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
            return res.status(409).json({ error: "Permission already assigned" });
          }
          throw e;
        }
      }

      return res.status(201).json(created);
    } catch (e) {
      console.error("CREATE TECH ERROR:", e);
      next(e);
    }
  }
);

adminRouter.patch(
  "/technicians/:id",
  requirePermission(Permission.TECH_MANAGE),
  async (req, res, next) => {
    try {
      const id = req.params.id;
      const body = technicianPatchSchema.parse(req.body);

      const existing = await prisma.user.findUnique({
        where: { id },
        select: { id: true, role: true, techDepartmentId: true, isActive: true },
      });
      if (!existing) throw new HttpError(404, "User not found");
      if (existing.role !== Role.TECHNICIAN) throw new HttpError(400, "Only technicians can be edited here");

      const hasDeptInBody = Object.prototype.hasOwnProperty.call(body, "techDepartmentId");

      // המחלקה "אחרי" השמירה: אם נשלחה מחלקה — קח אותה, אחרת קח את הקיימת
      const deptAfter = hasDeptInBody
        ? String((body as any).techDepartmentId ?? "").trim()
        : String(existing.techDepartmentId ?? "").trim();

      // ✅ כלל בסיס: אי אפשר לשמור טכנאי בלי מחלקה (גם אם רק משנים הרשאות/שם)
      if (!deptAfter) {
        throw new HttpError(400, "Technician must have a department");
      }

      // ✅ אם מפעילים – עדיין אותו כלל (אבל נשאיר הודעה ייעודית אם תרצה)
      if (body.isActive === true && !deptAfter) {
        throw new HttpError(400, "Cannot enable technician without department");
      }

      const data: any = {};
      if (body.username) data.username = body.username;
      if (body.name) data.name = body.name;
      if (body.isActive !== undefined) data.isActive = body.isActive;

      // אם הגיע techDepartmentId בבקשה — נשמור אותו (כבר עבר את החסימה למעלה)
      if (hasDeptInBody) data.techDepartmentId = deptAfter;

      if (body.password) data.passwordHash = await bcrypt.hash(body.password, 10);

      const updated = await prisma.user.update({
        where: { id },
        data,
        select: { id: true, username: true, name: true, role: true, techDepartmentId: true, isActive: true },
      });

      if (body.permissions) {
        await prisma.userPermission.deleteMany({ where: { userId: id } });
        if (body.permissions.length) {
          await prisma.userPermission.createMany({
            data: body.permissions.map((p: string) => ({ userId: id, perm: p as any })),
          });
        }
      }

      res.json(updated);
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.get(
  "/technicians/:id/usage",
  requirePermission(Permission.TECH_MANAGE),
  async (req, res, next) => {
    try {
      const id = req.params.id;

      const assignedTickets = await prisma.ticket.count({ where: { assigneeId: id } });
      const resolvedTickets = await prisma.ticket.count({ where: { resolvedById: id } });

      return res.json({ assignedTickets, resolvedTickets });
    } catch (e) {
      next(e);
    }
  }
);


/**
 * ✅ חדש: העברת כל הקריאות של טכנאי לטכנאי אחר (assigneeId)
 */
adminRouter.post(
  "/technicians/:id/reassign-tickets",
  requirePermission(Permission.TECH_MANAGE),
  async (req, res, next) => {
    try {
      const fromId = req.params.id;
      const { toTechnicianId } = req.body ?? {};
      if (!toTechnicianId) throw new HttpError(400, "Missing toTechnicianId");
      if (fromId === toTechnicianId) throw new HttpError(400, "Cannot reassign to same technician");

      const moved = await prisma.ticket.updateMany({
        where: { assigneeId: fromId },
        data: { assigneeId: toTechnicianId },
      });

      res.json({ ok: true, moved: moved.count });
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.delete(
  "/technicians/:id",
  requirePermission(Permission.TECH_MANAGE),
  async (req, res, next) => {
    try {
      const id = req.params.id;

      const user = await prisma.user.findUnique({ where: { id } });
      if (!user) throw new HttpError(404, "User not found");
      if (user.role !== Role.TECHNICIAN) throw new HttpError(400, "Only technicians can be disabled here");

      // לא בודקים assigned tickets — משביתים גם אם יש היסטוריה
      const updated = await prisma.user.update({
        where: { id },
        data: { isActive: false },
        select: { id: true, username: true, name: true, role: true, techDepartmentId: true, isActive: true },
      });

      res.json({ ok: true, item: updated });
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.delete(
  "/technicians/:id/permanent",
  requirePermission(Permission.TECH_MANAGE),
  async (req, res, next) => {
    try {
      const id = req.params.id;

      const user = await prisma.user.findUnique({
        where: { id },
        select: { id: true, role: true, isActive: true },
      });
      if (!user) throw new HttpError(404, "User not found");
      if (user.role !== Role.TECHNICIAN) throw new HttpError(400, "Only technicians can be deleted here");

      // ✅ רק אם לא פעיל
      if (user.isActive) throw new HttpError(400, "Cannot delete active technician");

      // ✅ אם קריאות משויכות לטכנאי (assigneeId / resolvedById) -> חסימה + רשימת מספרים
      const tickets = await prisma.ticket.findMany({
        where: {
          OR: [{ assigneeId: id }, { resolvedById: id }],
        },
        select: { number: true },
        orderBy: { number: "asc" },
      });

      if (tickets.length) {
        // ייתכנו כפילויות אם אותו טכנאי גם assigned וגם resolved — מנקים
        const uniqueNumbers = Array.from(new Set(tickets.map((t) => t.number)));

        return res.status(409).json({
          error: "Technician has tickets",
          details: { ticketNumbers: uniqueNumbers },
        });
      }

      // ✅ למחוק קודם permissions כדי לא להיתקע על FK
      await prisma.$transaction([
        prisma.userPermission.deleteMany({ where: { userId: id } }),
        prisma.user.delete({ where: { id } }),
      ]);

      return res.json({ ok: true });
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.patch("/technicians/:id/active", requirePermission(Permission.TECH_MANAGE), async (req, res, next) => {
  try {
    const id = req.params.id;
    const { isActive } = req.body ?? {};
    if (typeof isActive !== "boolean") throw new HttpError(400, "Missing isActive boolean");

    const updated = await prisma.user.update({
      where: { id },
      data: { isActive },
      select: { id: true, username: true, name: true, role: true, techDepartmentId: true, isActive: true },
    });

    res.json(updated);
  } catch (e) { next(e); }
});



/* =========================
   Ticket power actions
   ========================= */

adminRouter.post(
  "/tickets/:id/reassign",
  requirePermission(Permission.TICKET_REASSIGN),
  async (req, res, next) => {
    try {
      const id = req.params.id;
      const { assigneeId } = req.body ?? {};
      if (!assigneeId) throw new HttpError(400, "Missing assigneeId");

      const t = await prisma.ticket.update({ where: { id }, data: { assigneeId } });

      await prisma.ticketActivity.create({
        data: {
          ticketId: id,
          actorId: (req as any).user.sub,
          type: "reassign",
          message: "Ticket reassigned",
          metaJson: JSON.stringify({ assigneeId }),
        },
      });

      res.json(t);
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.post(
  "/tickets/:id/duplicate",
  requirePermission(Permission.TICKET_DUPLICATE),
  async (req, res, next) => {
    try {
      const id = req.params.id;
      const orig = await prisma.ticket.findUnique({ where: { id } });
      if (!orig) throw new HttpError(404, "Ticket not found");

      const c = await prisma.counter.upsert({
        where: { key: "ticketNumber" },
        update: { value: { increment: 1 } },
        create: { key: "ticketNumber", value: 1000 },
      });

      const copy = await prisma.ticket.create({
        data: {
          number: c.value,
          subject: `[COPY] ${orig.subject}`,
          description: orig.description,
          statusId: orig.statusId,
          priority: orig.priority,
          orgId: orig.orgId,
          assigneeId: orig.assigneeId,
          source: orig.source,
          externalRequesterName: orig.externalRequesterName,
          externalRequesterPhone: orig.externalRequesterPhone,
          hospitalDepartmentId: orig.hospitalDepartmentId,
        },
      });

      await prisma.ticketActivity.create({
        data: {
          ticketId: copy.id,
          actorId: (req as any).user.sub,
          type: "duplicate",
          message: `Duplicated from #${orig.number}`,
          metaJson: JSON.stringify({ from: orig.id }),
        },
      });

      res.status(201).json(copy);
    } catch (e) {
      next(e);
    }
  }
);

adminRouter.delete(
  "/tickets/:id",
  requirePermission(Permission.TICKET_DELETE),
  async (req, res, next) => {
    try {
      const id = req.params.id;
      await prisma.ticketActivity.deleteMany({ where: { ticketId: id } });
      await prisma.ticket.delete({ where: { id } });
      res.json({ ok: true });
    } catch (e) {
      next(e);
    }
  }
);
